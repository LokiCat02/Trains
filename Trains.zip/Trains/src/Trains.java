import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Trains {

	static String[] station_id;
    static String[] station_name;
    static String[] station_from;
    static String[] station_to;
    static String[] dept_time;
    static String[] arr_time;

	public static void main(String args[]) throws IOException, ParseException
	{
		try (BufferedReader br = new BufferedReader(new FileReader("stations.dat"));
			    BufferedReader bw = new BufferedReader(new FileReader("trains.dat"))) {
			    String line;int n=0;
			    int j=0;
			    while ((line = br.readLine()) != null) {
			    	n++;
			    }
			    System.out.println(n);
			    station_id=new String[n];
		        station_name=new String[n];
		        BufferedReader br1 = new BufferedReader(new FileReader("stations.dat"));
			    while ((line = br1.readLine()) != null) {
			        String[] values = line.split(" ");
			         
			          for(int i=0;i<values.length;i++)
			    {
			    	//System.out.println(values[i]+" "+i);
			    	station_id[j]=values[0];
			    	station_name[j]=values[1];
			    	
			    }
			    j++;
			   
			    }
			    for(int i=0;i<station_id.length;i++)
			    {
			    	System.out.println(station_id[i]+" "+station_name[i]);
			    }
			    String line1;
			    int k=0;int n1=0;
			    	   
			    while ((line1 = bw.readLine()) != null) {
			    n1++;
			    }
			    station_from=new String[n1];
		        station_to=new String[n1];
		        arr_time=new String[n1];
		        dept_time=new String[n1];
		        BufferedReader bw1 = new BufferedReader(new FileReader("trains.dat")); 
			    while ((line1 = bw1.readLine()) != null) {
			    	//int n=line1.split("\n").length;
			        String[] values = line1.split(" ");
			       
			        for(int i=0;i<values.length;i++)
				    {
			        System.out.println(values[i]+" "+i);
			        station_from[k]=values[0];
			    	station_to[k]=values[1];
			    	dept_time[k]=values[2];
			    	arr_time[k]=values[3];
			    	
			        	  }
			        k++;
			    }
			    }
			    
			    
			    	   
			    for(int i=0;i<station_from.length;i++)
			    System.out.println(station_from[i]+" "+station_to[i]+" "+dept_time[i]+" "+arr_time[i]);
				 
			    Graph g=new Graph(station_from.length-1);
			  
			    	for(int i=0;i<station_id.length;i++)
			    	{
			    		System.out.println(Integer.parseInt(station_id[i])+" to "+ station_name[i]);
			    		g.setLabel(Integer.parseInt(station_id[i]), station_name[i]);
			    	}
			    	
			    	
			    	for(int i=0;i<station_from.length;i++)
			    	{
			    	String milTime=arr_time[i];
					String milTime1=dept_time[i];
					int k=Integer.parseInt(milTime);
					int j=Integer.parseInt(milTime1);
					// Convert the int to a string ensuring its 4 characters wide, parse as a date 
					Date date = new SimpleDateFormat("hhmm").parse(String.format("%04d", k));
					// Set format: print the hours and minutes of the date, with AM or PM at the end 
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm a");
					// Print the date!
					Date date2 = new SimpleDateFormat("hhmm").parse(String.format("%04d", j));
					//System.out.println(date2.getTime());
					// Output: 12:56 AM	
				/*	if(date.getTime()<0 )
						date.setTime(date.);
						
						
*/			            if(date.getTime()>0 &&date2.getTime()>0){
	if(date.getTime()>date2.getTime()){
		long diff = date.getTime() - date2.getTime();
					   // System.out.println(date2.getTime());
				        long diffSeconds = diff / 1000 % 60;
				        long diffMinutes = diff / (60 * 1000) % 60;
				        long diffHours = diff / (60 * 60 * 1000);
				        long totseconds=(diffHours*60*60)+diffMinutes*60;
				        String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
				        int x=Integer.parseInt(shortest);
				        g.addEdge(Integer.parseInt(station_from[i])-1,Integer.parseInt(station_to[i])-1,totseconds);

	}
	else if(date2.getTime()>date.getTime()){
		long diff = date2.getTime() - date.getTime();
					   // System.out.println(date2.getTime());
				        long diffSeconds = diff / 1000 % 60;
				        long diffMinutes = diff / (60 * 1000) % 60;
				        long diffHours = diff / (60 * 60 * 1000);
				        long totseconds=(diffHours*60*60)+diffMinutes*60;
				        String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
				        int x=Integer.parseInt(shortest);
				        g.addEdge(Integer.parseInt(station_from[i])-1,Integer.parseInt(station_to[i])-1,totseconds);

	}}
	else
	{
		if(date.getTime()>date2.getTime()){
	long diff = date.getTime() - date2.getTime();
    System.out.println(date2.getTime());
    long diffSeconds = diff / 1000 % 60;
    long diffMinutes = diff / (60 * 1000) % 60;
    long diffHours = ((diff / (60 * 60 * 1000))-12);
    long totseconds=(diffHours*60*60)+diffMinutes*60;
    String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
    int x=Integer.parseInt(shortest);
    g.addEdge(Integer.parseInt(station_from[i])-1,Integer.parseInt(station_to[i])-1,totseconds);
		}
	else if(date2.getTime()>date.getTime()){
			
				long diff = date2.getTime() - date.getTime();
			    System.out.println(date2.getTime());
			    long diffSeconds = diff / 1000 % 60;
			    long diffMinutes = diff / (60 * 1000) % 60;
			    long diffHours = (diff / (60 * 60 * 1000))-(12);
			    long totseconds=(diffHours*60*60)+diffMinutes*60;
			    String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
			    int x=Integer.parseInt(shortest);
			    g.addEdge(Integer.parseInt(station_from[i])-1,Integer.parseInt(station_to[i])-1,totseconds);
	

	}
			    	}
			    	}
			    //for(int i=0;i<station_from.length;i++)
			   // g.addEdge(Integer.parseInt(station_from[i]),Integer.parseInt(station_to[i]));
			    System.out.println("The adjacency matrix is");
				 
			    for(int i=0;i<g.labels.length;i++)
			    {
			    	for(int j=0;j<g.labels.length;j++)
			    	{
			    		
			    		System.out.print(g.edges[i][j]+" ");
			    	}
			    	System.out.println();
			    }
			    
			    System.out.println("The graph obtained from the train route is");
			    g.print();
			    
			    
			    System.out.println();
			    
			    int e=0;
			    while(e!=1){
			    
			    System.out.println("========================================================================  "+"\n" +"                       READING RAILWAYS SCHEDULER"+"\n"+"========================================================================"+ "\n"+"Options - (Enter the number of your selected option)" +"\n"+"(1) - Print full schedule"+" (2) - Print station schedule "+"\n"+"(3) - Look up stationd id "+"\n"+"(4) - Look up station name "+"\n"+"(5) - Servie available "+"\n"+"(6) - Nonstop service available"+"\n"+"(7) - Find route (Shortest riding time) "+""
			    		+ "\n"+"(8) - Find route (Shortest overall travel time) "+"\n"+"(9) - Exit");
			    
			    Scanner s=new Scanner(System.in);
			    int c=s.nextInt();
			    switch(c)
			    {
			    case 1:printschedule();break;
			    
			    case 2:printstationschedule();break;
			    case 3:lookupname();break;
			    case 4:lookupid();break;
			    case 5:lookupservice();break;
			    case 6:lookupnontstop();break;
			    case 7:findshortestroute( g);break;
			    case 8:findshortestoverall(g);break;
			    case 9:e=1;
			    }
			    }
			      
	}
	private static void findshortestoverall(Graph g) throws ParseException {
		// TODO Auto-generated method stub
				// Heres your military time int like in your code sample
				System.out.println("Enter Departure Stationid:");
				int dep=s1.nextInt();
				System.out.println("Enter Departure Stationid:");
				int des=s1.nextInt();
				
				//To print shortest path
			       final int [] pred = Dijkstra.dijkstra (g, 1);
			       System.out.println();
			      // System.out.println("The shortest path between a and k is");
			       List<String> l=new ArrayList();
			       l= Dijkstra.printPath (g, pred, dep-1,des-1 );
			       //System.out.println(l);
			       String[] a3 = new String[l.size()];
			       if(l.size()<0)
			       {
			    	   System.out.println("No route exists");
			       }
			       for(int i=0;i<l.size();i++)
			       {
			    	  // System.out.println(l.get(i));
			    	   a3[i]=l.get(i);
			       }
			       //System.out.println(a3);
			       int[] b=new int[l.size()];
			       for(int i=0;i<l.size();i++)
			       {
			    	   //System.out.println(a3[i]);
			 	      
			    	   b[i]=g.getLabel(a3[i]+"")+1;
			    	 //  System.out.println(b[i]);
			       }
			       for(int i=0;i<b.length-1;i++)
			       {
			    	   int from=b[i];
			    	   int to=b[i+1];
			    	   sum+=g.edges[from-1][to-1];
			    	   System.out.println();
			       }
			       int hours=sum;
			       int minutes=0;
			       int sec=0;
			       if(hours>=3600)
			       {
			    	  hours/=3600;
			    	  minutes=sum%3600;
			    	  minutes/=60;
			    	 // System.out.println("Time taken to travel is : "+hours+" hours "+minutes+" minutes");
				       
			       }
			       else
			       {
			    	   minutes=sum/60;
			    	   sec=sum%60;
			    	  // System.out.println("Time taken to travel is : "+minutes+" minutes "+sec+" Seconds");
				       
			       }
			       int a=b[0];
			       int c=b[b.length-1];
			       int st=0,to=0;
			       for(int i=0;i<station_from.length;i++)
			       {
			    	   if((station_from[i].equals(Integer.toString(a))&&(station_to[i].equals(Integer.toString(b[1])))))
			    	   {
			    		   st=i;
			    		   
			    	   }
			    	  
			       }
			       for(int i=0;i<station_from.length-1;i++)
			       {
			    	   if((station_to[i].equals(Integer.toString(c))&&((station_from[i].equals(Integer.toString(b[b.length-2]))))))
			    	   {
			    		   to=i;
			    		   
			    	   }
			    	  
			       }
			       String x=dept_time[st];
			       //System.out.println(x);
			        String y=arr_time[to];
			        //System.out.println(y);
				      
			       int k=Integer.parseInt(x);
					int j=Integer.parseInt(y);
					// Convert the int to a string ensuring its 4 characters wide, parse as a date 
					Date date = new SimpleDateFormat("hhmm").parse(String.format("%04d", k));
					// Set format: print the hours and minutes of the date, with AM or PM at the end 
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm a");
					// Print the date!
					Date date2 = new SimpleDateFormat("hhmm").parse(String.format("%04d", j));
					//System.out.println(date2.getTime());
					long diff = date2.getTime() - date.getTime();
				    //System.out.println(date);
				    //System.out.println(date2);
			        long diffSeconds = diff / 1000 % 60;
			        long diffMinutes = diff / (60 * 1000) % 60;
			        long diffHours = diff / (60 * 60 * 1000);
			        //System.out.println(diffHours);
			        long totseconds=(diffHours*60*60)+diffMinutes*60;
			       // String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
			        //int x1=Integer.parseInt(shortest);
			       System.out.println("Shortest overall time is:  "+ diffHours+" Hours "+diffMinutes+" minutes");
			       
			       System.out.println("itenary");
			       System.out.println("------------------------------------");
			       int st1=0,to11=0;
			       for(int i=0;i<b.length-1;i++)
			       {
			    	   int from=b[i];
			    	   int to1=b[i+1];
			    	   //sum+=g.edges[from-1][to-1];
			    	   for(j=0;j<station_id.length;j++){
			    	   if(station_id[j].equals(Integer.toString(from)))
			    	   {
			    		   st=j;
			    		   //System.out.println(st);
			    		   
			    	   }}
			    	   for(j=0;j<station_id.length;j++){
				    	   if(station_id[j].equals(Integer.toString(to1)))
				    	   {
				    		   to=j;
				    		   //System.out.println(to);
				    		   
				    	   }}
			    	   for(j=0;j<station_id.length;j++){
				    	   if(station_from[j].equals(Integer.toString(from))&&(station_to[j].equals(Integer.toString(to1))))
				    	   {
				    		   st1=j;
				    		   //System.out.println(st);
				    		   
				    	   }}
				    	   for(j=0;j<station_id.length;j++){
					    	   if((station_to[j].equals(Integer.toString(to1))&&((station_from[j].equals(Integer.toString(from))))))
					    	   {
					    		   to11=j;
					    		   //System.out.println(to);
					    		   
					    	   }}
			    	  System.out.println("Leave from "+station_name[st]+" at "+dept_time[st1]+" "
			    		+"arrives at "+station_name[to]+",at "+arr_time[to11]);
			       }
	/*	// TODO Auto-generated method stub
		findshortestroute(g);
		System.out.println("Enter Departure Stationid:");
		int dep=s1.nextInt();
		System.out.println("Enter Departure Stationid:");
		int des=s1.nextInt();
		
	        System.out.println();
	       AllPaths path1= new AllPaths(g, Integer.toString(dep-1),Integer.toString(des-1));
	       String s=path1.path1.toString();
	       System.out.println(s1);
	       String s1=s.substring(2, s.length()-2);
	       
	       String[] s2=s1.split(", ");
	       //System.out.println(s2[4]);
	       int[] n=new int[s2.length];
	       for(int i=0;i<s2.length;i++)
	       {
	    	   n[i]=Integer.parseInt(s2[i]);
	    	   //System.out.println(n[i]);
	       }
	       int st = 0,to = 0;
	       for(int i=0;i<station_from.length;i++)
	       {
	    	   if(station_from[i].equals(Integer.toString(n[0]+1)))
	    	   {
	    		   st=i;
	    		   
	    	   }
	    	  
	       }
	       for(int i=0;i<station_from.length;i++)
	       {
	    	   if(station_to[i].equals(Integer.toString(n[n.length-1]+1)))
	    	   {
	    		   to=i;
	    		   
	    	   }
	    	  
	       }
	       String x=dept_time[st];
	       //System.out.println(x);
	        String y=arr_time[to];
	        //System.out.println(y);
		      
	       int k=Integer.parseInt(x);
			int j=Integer.parseInt(y);
			// Convert the int to a string ensuring its 4 characters wide, parse as a date 
			Date date = new SimpleDateFormat("hhmm").parse(String.format("%04d", k));
			// Set format: print the hours and minutes of the date, with AM or PM at the end 
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm a");
			// Print the date!
			Date date2 = new SimpleDateFormat("hhmm").parse(String.format("%04d", j));
			//System.out.println(date2.getTime());
			long diff = date2.getTime() - date.getTime();
		    //System.out.println(date2);
	        long diffSeconds = diff / 1000 % 60;
	        long diffMinutes = diff / (60 * 1000) % 60;
	        long diffHours = diff / (60 * 60 * 1000);
	        System.out.println(diffHours);
	        long totseconds=(diffHours*60*60)+diffMinutes*60;
	        String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
	        int x1=Integer.parseInt(shortest);
	        System.out.println("Shortest overall time is: "+ diffHours+" Hours "+diffMinutes+" minutes");
	
	        
		       System.out.println("itenary");
		       System.out.println("------------------------------------");
		       for(int i=0;i<n.length-1;i++)
		       {
		    	   int from1=n[i];
		    	   int to1=n[i+1];
		    	   //sum+=g.edges[from-1][to-1];
		    	  System.out.println("Leave from "+station_name[from1]+" at "+arr_time[from1]+" "
		    		+"arrives at "+station_name[to1]+",at "+dept_time[to1]);
		       }*/
			 
	}
	static int sum;
	private static void findshortestroute(Graph g) throws ParseException {
		// TODO Auto-generated method stub
		// Heres your military time int like in your code sample
		System.out.println("Enter Departure Stationid:");
		int dep=s1.nextInt();
		System.out.println("Enter Departure Stationid:");
		int des=s1.nextInt();
		
		//To print shortest path
	       final int [] pred = Dijkstra.dijkstra (g, 1);
	       System.out.println();
	      // System.out.println("The shortest path between a and k is");
	       List<String> l=new ArrayList();
	       l= Dijkstra.printPath (g, pred, dep-1,des-1 );
	       //System.out.println(l);
	       String[] a3 = new String[l.size()];
	       if(l.size()<0)
	       {
	    	   System.out.println("No route exists");
	       }
	       for(int i=0;i<l.size();i++)
	       {
	    	  // System.out.println(l.get(i));
	    	   a3[i]=l.get(i);
	       }
	       //System.out.println(a3);
	       int[] b=new int[l.size()];
	       for(int i=0;i<l.size();i++)
	       {
	    	   //System.out.println(a3[i]);
	 	      
	    	   b[i]=g.getLabel(a3[i]+"")+1;
	    	 //  System.out.println(b[i]);
	       }
	       for(int i=0;i<b.length-1;i++)
	       {
	    	   int from=b[i];
	    	   int to=b[i+1];
	    	   System.out.println(g.edges[from-1][to-1]);
	    	   sum+=g.edges[from-1][to-1];
	       }
	       int hours=sum;
	       int minutes=0;
	       int sec=0;
	       if(hours>=3600)
	       {
	    	  hours/=3600;
	    	  minutes=sum%3600;
	    	  minutes/=60;
	    	  System.out.println("Time taken to travel is : "+hours+" hours "+minutes+" minutes");
		       
	       }
	       else
	       {
	    	   minutes=sum/60;
	    	   sec=sum%60;
	    	   System.out.println("Time taken to travel is : "+minutes+" minutes "+sec+" Seconds");
		       
	       }
	       
	       System.out.println("itenary");
	       System.out.println("------------------------------------");
	       int st=0,to=0;int j=0;int st1=0,to11=0;
	       for(int i=0;i<b.length-1;i++)
	       {
	    	   int from=b[i];
	    	   int to1=b[i+1];
	    	   //sum+=g.edges[from-1][to-1];
	    	   for(j=0;j<station_id.length;j++){
	    	   if(station_id[j].equals(Integer.toString(from)))
	    	   {
	    		   st=j;
	    		   //System.out.println(st);
	    		   
	    	   }}
	    	   for(j=0;j<station_id.length;j++){
		    	   if(station_id[j].equals(Integer.toString(to1)))
		    	   {
		    		   to=j;
		    		   //System.out.println(to);
		    		   
		    	   }}
	    	   for(j=0;j<station_id.length;j++){
		    	   if(station_from[j].equals(Integer.toString(from))&&(station_to[j].equals(Integer.toString(to1))))
		    	   {
		    		   st1=j;
		    		   //System.out.println(st);
		    		   
		    	   }}
		    	   for(j=0;j<station_id.length;j++){
			    	   if((station_to[j].equals(Integer.toString(to1))&&((station_from[j].equals(Integer.toString(from))))))
			    	   {
			    		   to11=j;
			    		   //System.out.println(to);
			    		   
			    	   }}
	    	  System.out.println("Leave from "+station_name[st]+" at "+dept_time[st1]+" "
	    		+"arrives at "+station_name[to]+",at "+arr_time[to11]);
	       }
		 
	}
	private static void lookupnontstop() {
		 System.out.println("Enter departure station id:");
		 int dep=s1.nextInt();
		 System.out.println("Enter destination station id:");
		 int des=s1.nextInt();	
		int flag=0;
		 for(int i=0;i<station_from.length;i++)
		 {
			 if((station_from[i].equals(Integer.toString(dep)))&&(station_to[i].equals(Integer.toString(des))))
					 {
				 System.out.println("Service is avalible from  "+station_name[dep-1]+" to "+station_name[des-1]);
	                flag=1; }
			 
		 }
		 if(flag!=1)
		 {
			 System.out.println("No non stop service available");
		 }
	}
	static Scanner s1=new Scanner(System.in);
	
	private static void lookupservice() {
		// TODO Auto-generated method stub
		 System.out.println("Enter departure station id:");
		 int dep=s1.nextInt();
		 System.out.println("Enter destination station id:");
		 int des=s1.nextInt();	
		int flag=0;
		 for(int i=0;i<station_from.length;i++)
		 {
			 if((station_from[i].equals(Integer.toString(dep)))&&(station_to[i].equals(Integer.toString(des))))
					 {
				 System.out.println("Service is avalible from  "+station_name[dep-1]+" to "+station_name[des-1]);
	                flag=1; }
			 
		 }
		 if(flag!=1)
		 {
			 System.out.println("No service available");
		 }
	}
	
	 private static void lookupid() {
		// TODO Auto-generated method stub
		 System.out.println("Enter Station id:");
		 int sid=s1.nextInt();
		 for(int i=0;i<station_id.length;i++)
		 {
			 if(station_id[i].equals(Integer.toString(sid)))
					 {
				 System.out.println("Station name is: "+station_name[i]);
					 }
		 }
		
	}
	 
	 private static void lookupname() {
			// TODO Auto-generated method stub
			 System.out.println("Enter Station name:");
			 String sid=s1.next();
			 for(int i=0;i<station_id.length;i++)
			 {
				 if(station_name[i].equals((sid)))
						 {
					 System.out.println("Station id is: "+station_id[i]);
						 }
			 }
			
		}
		
	private static void printstationschedule() {
		// TODO Auto-generated method stub
		System.out.println("Enter Station id:");
		int sid=s1.nextInt();
		int x1=0;
		for(int i=0;i<station_id.length;i++)
		{
			if(station_id[i].equals(Integer.toString(sid)))
				System.out.println("schedule for "+station_name[i]);
			
		}
		
		for(int i=0;i<station_from.length;i++)
		{
			if(station_from[i].equals(Integer.toString(sid)))
			{
				int x=Integer.parseInt(station_to[i]);
				System.out.println("Departure to "+station_name[x-1]+" "+"at "+dept_time[i]+"  arriving at "+arr_time[i]);
			}
			
		}
		
		for(int i=0;i<station_from.length;i++)
		{
		 if(station_to[i].equals(Integer.toString(sid)))
		{
			int x=Integer.parseInt(station_from[i]);
			System.out.println("Arrival from "+station_name[x-1]+" "+"at "+(Integer.parseInt(arr_time[i])));
		}
		}
	}

	private static void printschedule() {
		// TODO Auto-generated method stub
		System.out.println("Train starts from station:           "+"Train goes to station:           "+"Arrival Time:        "+"Departure Time:          ");
		for(int i=0;i<station_from.length;i++)
		{
			System.out.println("             "+station_from[i]+"                                 "+station_to[i]+"                       "+(dept_time[i].substring(0, 2)+"::"+dept_time[i].substring(2, 4))+"                    "+(arr_time[i].substring(0, 2)+"::"+arr_time[i].substring(2, 4)));
		}
	}	
	
	
	
	}

