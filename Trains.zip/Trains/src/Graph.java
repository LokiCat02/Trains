import java.util.Scanner;

public class Graph {
 
    public static long [][]  edges;  // adjacency matrix
    public static Object [] labels;
    static String[]temp ;
    static int [][] temp1;
    public int current_edge_weight;
    private int[] next;

    public Graph (int n) {
        edges  = new long [n][n];
        labels = new String[n];
     }
  
  
     public int size() { return labels.length; }
  
     public void setLabel (int vertex, String label) { labels[vertex-1]=label;
     //System.out.println(vertex+" "+label);}
     if(vertex==labels.length-1)
     {
    	 labels[vertex]=label.replace("\n", "");
     }
     }
     public int getLabel (String string)               { 
    	 int x=0; 
    	 //System.out.println(labels[7]);
     	for(int i=0;i<labels.length;i++)
     {
     	if(labels[i].equals(string))
     	{
     		x=i;
     	}
     
     }
     		return x;}
     
     public int nextneighbor(int v) {
    	 next = new int[labels.length];
         for (int i = 0; i < labels.length; i++)			
            next[i] = -1;
         next[v] = next[v] + 1; 				

         if(next[v] < labels.length){
         	while(edges[v][next[v]] == 0 && next[v] < labels.length) {
               next[v] = next[v] + 1;                        

               if(next[v] == labels.length)
            	   break;
            }
        }

         if(next[v] >= labels.length) {
            next[v] = -1;                                    
            current_edge_weight = -1;
         }
         else 
            current_edge_weight = (int) edges[v][next[v]];

        // System.out.println(next[v]);
         return next[v];      				
      } 
  
     public void    addEdge    (int source, int target)  { edges[source][target] = 1;
     System.out.println();
     System.out.println("Edge from "+source +" to "+target+" added successfully");}
     
     public void    addEdge    (int source, int target, long totseconds)  { edges[source][target] = totseconds; 
     System.out.println();
     System.out.println("Edge from "+source +" to "+target+" added successfully");}
     
     public boolean isEdge     (int source, int target)  { return edges[source][target]>0; }
     public void    removeEdge (int source, int target)  { edges[source][target] = 0; 
     System.out.println();
     System.out.println("Edge from "+source +" to "+target+" removed successfully");
     System.out.println();}
     
     public int     getWeight  (int source, int target)  { return (int) edges[source][target]; }
     public void     setWeight  (int source, int target,int w)  {  edges[source][target] =w; }
     
     public int [] neighbors (int vertex) {
        int count = 0;
        for (int i=0; i<edges[vertex].length; i++) {
           if (edges[vertex][i]>0) count++;
        }
        final int[]answer= new int[count];
        count = 0;
        for (int i=0; i<edges[vertex].length; i++) {
           if (edges[vertex][i]>0) answer[count++]=i;
        }
        return answer;
     }
     public boolean isEmpty()
     {
    	 if(labels.length<=0 || edges.length<=0)
    		 return true;
    	 else
    		 return false;
     }
     public boolean isComplete()
     {
    	 int n=0;
    	 for(int i=0;i<labels.length;i++)
    	 {
    		 for(int j=0;j<labels.length;j++)
    		 {
    			 if(edges[i][j]!=0)
    				 n+=1;
    		 }
    	 }
    	 int x=n*((n-1)/2);
    	 int flag1=0,flag2=0;
    	 if(n==x)
    		flag1=1;    	
    	 for(int i=0;i<labels.length;i++){ 
    	  for(int j=i+1;j<labels.length;j++)
    	  {
    		  if(edges[i][j]!=0)
    			  flag2=1;
    	  }
    	 }
		if(flag1==1&&flag2==1)
			return true;
		else
			return false;
    	 
     }
     public int degree(int v)
     {
    	 int n=0;
    	 for(int i=0;i<labels.length;i++)
    	 {
    			 if(edges[i][v]!=0)
    				 n+=1;
    	 }
    	 return n;
     }
   public boolean isDirected()
   {
	   boolean x=true;
	   for(int i=0;i<labels.length;i++)
       {
    	   for(int j=0;j<labels.length;j++)
    	   {
    		   if((edges[i][j]!=0)&&(i!=j)){
    		   if(edges[i][j]==edges[j][i])
    		   {
    			   return false;
    		   }}
    	   }
       }
    	   
	return x;
	   
   }
   public int vertices()
   {
	   int n=labels.length;
	return n;
   }
   public int edges(){
	   int n=0;
	   for(int i=0;i<labels.length;i++)
	   {
		   for(int j=0;j<labels.length;j++)
		   {
			   if(edges[i][j]!=0)
				   n+=1;
		   }
	   }
	   return n;
   }
   public void addVertex(String v)
   {
	Scanner s=new Scanner(System.in);
	 int i=0;
	 int l=getLabel("v");
	 i=labels.length;
	   labels[i-1]=v;
	   for(i=0;i<labels.length;i++)
	   { 
			   edges[i][l]=0;
			   
		   
	   }
	   System.out.println("Vertex "+v+" added successfully");}
   
	  
   public void removeVertex(String v)
   {
	Scanner s=new Scanner(System.in);
	temp = new String[labels.length - 1];
	 int i=0,count=0;
	 //int l=getLabel();
	 for(i=0;i<labels.length;i++){
		 //System.out.println("label"+labels[i]+"passed"+v);
	 if((labels[i]).equals(v))
     {
         for(int j=i; j<(labels.length-1); j++)
         {
        	 labels[j] = labels[j+1];
         }
         count++;
         break;
     }
	 }
	 if(count==0)
     {
         System.out.print("Vertex Not Found..!!");
     }
     else
     {
         System.out.print("Vertrx "+v+" Removed Successfully..!!");
         System.out.print("\nNow the New Array is :\n");
         String[]temp=new String[labels.length-1];
         //labels[getLabel(v)]="";
     }
	
	 for(i=0;i<labels.length;i++)
	 {
		 for(int j=0;j<labels.length;j++)
		 {
		// edges[i][l]=0;	 
		 //edges[l][j]=0;
	 }
	 }
   for(i=0;i<labels.length;i++)
	   {
	   for(int j=0;j<labels.length;j++)
		   {
		   System.out.print(edges[i][j]+" ");
		   }
	   System.out.println();
		   }
   //System.out.println("Vertex "+v+" removed successfully");
   
	 }
   public boolean adjacent(int v,int u)
   {
	  if(edges[v][u]!=0)
		  return true;
	  else
		  return false;
   }
     public void print () {
        for (int j=0; j<edges.length; j++) {
           System.out.print (labels[j]+": ");
           for (int i=0; i<edges[j].length; i++) {
              if (edges[j][i]>0) System.out.print (labels[i]+":"+edges[j][i]+" ");
           }
           System.out.println ();
        }
     }
     public String[] adjacentTo(int v)
     {
    	 String[] adj =new String[100];
    	 int k=0;
    	 for(int i=0;i<edges.length;i++)
    	 {
    		 for(int j=0;j<edges.length;j++)
    		 {
    			 if(edges[i][v]!=0)
    			 {
    				 adj[k]=Integer.toString(i);
    				 k++;
    			 }
    			 else if(edges[v][j]!=0)
    			 {
    				 adj[k]=Integer.toString(j);
    				 k++;
    			 }
    			
    		 }
    	 }
		return adj;
    	 
     }
}