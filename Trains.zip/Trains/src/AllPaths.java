import java.util.Stack;

public class AllPaths<Vertex> {

    public Stack<String> path  = new Stack<String>();   // the current path
    public SET<String> onPath  = new SET<String>();     // the set of vertices on the path
    public Stack<String> path1=new Stack<String>();
    
    public AllPaths(Graph G, String s, String t) {
        enumerate(G, s, t);
    }

    // use DFS
    private String enumerate(Graph G, String v, String t) {

        // add node v to current path from s
        path.push(v);
        onPath.add(v);

        // found path from s to t - currently prints in reverse order because of stack
        if (v.equals(t)) {
            System.out.println(path.toString());
            path1.push(path.toString());
        }

        // consider all neighbors that would continue path with repeating a node
        else {
            for (int u : G.neighbors(Integer.parseInt(v))) {
            	String w=Integer.toString(u);
                if (!onPath.contains(w)) enumerate(G, w, t);
            }
        }

        // done exploring from v, so remove from path
        path.pop();
        onPath.delete(v);
        return path.toString();
    }

    public static void main(String[] args) {
        /*Graph G = new Graph(9);
        G.addEdge(1,2);
        G.addEdge(2,3);
        G.addEdge(3,4);
        G.addEdge(4,5);
        G.addEdge(3,5);
        G.addEdge(2,5);
        G.addEdge(5,3);
        G.addEdge(3,6);
        G.addEdge(4,6);
        System.out.println(G);*/
           }

}

