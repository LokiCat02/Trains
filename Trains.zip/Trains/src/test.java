import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class test {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		String x1="0500";
		String y1="0600";
		int k=Integer.parseInt(x1);
		int j=Integer.parseInt(y1);
		Date date = new SimpleDateFormat("hhmm").parse(String.format("%04d", k));
		// Set format: print the hours and minutes of the date, with AM or PM at the end 
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm a");
		// Print the date!
		
		Date date2 = new SimpleDateFormat("hhmm").parse(String.format("%04d", j));
		int v=(int) date.getTime();
		
		System.out.println(date);
		 if(date.getTime()>0 &&date2.getTime()>0){
				
					long diff = date2.getTime() - date.getTime();
								   // System.out.println(date2.getTime());
							        long diffSeconds = diff / 1000 % 60;
							        long diffMinutes = diff / (60 * 1000) % 60;
							        long diffHours = diff / (60 * 60 * 1000);
							        long totseconds=(diffHours*60*60)+diffMinutes*60;
							        String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
							        int x=Integer.parseInt(shortest);
							       // g.addEdge(Integer.parseInt(station_from[i])-1,Integer.parseInt(station_to[i])-1,totseconds);
System.out.println(totseconds+" 1");
				}
				
				else
				{
					
				long diff = date2.getTime() - date.getTime();
			   // System.out.println(date2.getTime());
			    long diffSeconds = diff / 1000 % 60;
			    long diffMinutes = diff / (60 * 1000) % 60;
			    long diffHours = (diff / (60 * 60 * 1000))-(12);
			    long totseconds=(diffHours*60*60)+diffMinutes*60;
			    String shortest=Long.toString(diffHours)+Long.toString(diffMinutes);
			    int x=Integer.parseInt(shortest);
			   // g.addEdge(Integer.parseInt(station_from[i])-1,Integer.parseInt(station_to[i])-1,totseconds);
			    System.out.println(totseconds+" 2");	
						    	}
	
	}
}
